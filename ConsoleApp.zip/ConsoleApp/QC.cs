﻿namespace ConsoleApp
{
    public class QC
    {
    }
}