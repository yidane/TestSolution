﻿namespace ConsoleApp
{
    public class ProductInfo
    {
    }
}